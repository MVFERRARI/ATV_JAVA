public class Main {
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente("12345", "João Silva", 500.0, 1000.0);
        ContaPoupanca cp = new ContaPoupanca("67890", "Maria Santos", 200.0);
        ContaInvestimento ci = new ContaInvestimento("11223", "Carlos Pereira", 5000.0);
        ContaSalario cs = new ContaSalario("44556", "Ana Souza", 1500.0, 500.0);
        ContaInvestimentoAltoRisco cial = new ContaInvestimentoAltoRisco("77889", "Fernando Lima", 12000.0);

        System.out.println("\n--- Teste Conta Corrente ---");
        cc.exibirInformacoes();
        cc.sacar(600);
        cc.exibirInformacoes();

        System.out.println("\n--- Teste Conta Poupança ---");
        cp.exibirInformacoes();
        cp.sacar(250);
        cp.exibirInformacoes();

        System.out.println("\n--- Teste Conta Investimento ---");
        ci.exibirInformacoes();
        ci.sacar(1000);
        ci.exibirInformacoes();

        System.out.println("\n--- Teste Conta Salário ---");
        cs.exibirInformacoes();
        cs.sacar(200);
        cs.sacar(200);
        cs.exibirInformacoes();

        System.out.println("\n--- Teste Conta Investimento Alto Risco ---");
        cial.exibirInformacoes();
        cial.sacar(2000);
        cial.exibirInformacoes();
    }
}
