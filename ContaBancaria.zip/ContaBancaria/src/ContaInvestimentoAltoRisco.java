class ContaInvestimentoAltoRisco extends ContaInvestimento {
    private static final double TAXA_SAQUE_ALTO_RISCO = 0.05;
    private static final double SALDO_MINIMO_SAQUE = 10000.0;

    public ContaInvestimentoAltoRisco(String numeroConta, String titular, double saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public boolean sacar(double valor) {
        if (saldo < SALDO_MINIMO_SAQUE) {
            System.out.println("Saque não permitido. Saldo mínimo de R$ 10.000,00 é exigido.");
            return false;
        }

        double valorComTaxa = valor + (valor * TAXA_SAQUE_ALTO_RISCO);
        return super.sacar(valorComTaxa);
    }
}
