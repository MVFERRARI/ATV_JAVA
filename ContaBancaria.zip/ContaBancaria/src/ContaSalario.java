class ContaSalario extends ContaCorrente {
    private int saquesGratuitos = 1;

    public ContaSalario(String numeroConta, String titular, double saldo, double limiteChequeEspecial) {
        super(numeroConta, titular, saldo, limiteChequeEspecial);
    }

    @Override
    public boolean sacar(double valor) {
        if (saquesGratuitos > 0) {
            saquesGratuitos--;
            return super.sacar(valor);
        } else {
            double valorComTaxa = valor + 5.00;
            return super.sacar(valorComTaxa);
        }
    }
}
