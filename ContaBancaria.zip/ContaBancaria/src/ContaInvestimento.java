class ContaInvestimento extends ContaBancaria {
    private static final double TAXA_SAQUE = 0.02;

    public ContaInvestimento(String numeroConta, String titular, double saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public boolean sacar(double valor) {
        double valorComTaxa = valor + (valor * TAXA_SAQUE);
        if (valorComTaxa <= saldo) {
            saldo -= valorComTaxa;
            System.out.println("Saque realizado com taxa de 2%. Novo saldo: " + saldo);
            return true;
        } else {
            System.out.println("Saldo insuficiente para saque com taxa.");
            return false;
        }
    }
}
