import classes.*;

public class Main {
        public static void main(String[] args) {
            Carro carro = new Carro("Toyota", "Corolla", 2022, 5, "Sedan");
            Caminhao caminhao = new Caminhao("Volvo", "FH", 2020, 2, 10);
            Onibus onibus = new Onibus("Mercedes", "O500", 2018, 40, 6);
            CarroEletrico carroEletrico = new CarroEletrico("Tesla", "Model S", 2023, 5, "Sedan", 100);
            CaminhaoRefrigerado caminhaoRefrigerado = new CaminhaoRefrigerado("Scania", "R450", 2021, 2, 8, -18);

            System.out.println("Carro:");
            carro.exibirDetalhes();
            System.out.println("Autonomia: " + carro.calcularAutonomia() + " km\n");

            System.out.println("Caminhão:");
            caminhao.exibirDetalhes();
            System.out.println("Autonomia: " + caminhao.calcularAutonomia() + " km\n");

            System.out.println("Ônibus:");
            onibus.exibirDetalhes();
            System.out.println("Autonomia: " + onibus.calcularAutonomia() + " km\n");

            System.out.println("Carro Elétrico:");
            carroEletrico.exibirDetalhes();
            System.out.println("Autonomia: " + carroEletrico.calcularAutonomia() + " km\n");

            System.out.println("Caminhão Refrigerado:");
            caminhaoRefrigerado.exibirDetalhes();
            System.out.println("Autonomia: " + caminhaoRefrigerado.calcularAutonomia() + " km\n");
        }
    }
