package classes;

public class Onibus extends Veiculo {
    private int quantidadeEixos;
    private final int tanque = 200;
    private final double consumo = 5;

    public Onibus(String marca, String modelo, int ano, int capacidadePassageiros, int quantidadeEixos) {
        super(marca, modelo, ano, capacidadePassageiros, "Diesel");

        if (quantidadeEixos < 6 || quantidadeEixos > 8) {
            throw new IllegalArgumentException("Ônibus deve ter entre 6 e 8 eixos.");
        }
        this.quantidadeEixos = quantidadeEixos;
    }

    @Override
    public double calcularAutonomia() {
        return tanque * consumo;
    }
}

