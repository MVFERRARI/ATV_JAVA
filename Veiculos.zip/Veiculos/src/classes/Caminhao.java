package classes;

public class Caminhao extends Veiculo {
    private double capacidadeCarga;
    private final int tanque = 300;
    private final double consumoBase = 6;

    public Caminhao(String marca, String modelo, int ano, int capacidadePassageiros, double capacidadeCarga) {
        super(marca, modelo, ano, capacidadePassageiros, "Diesel");
        this.capacidadeCarga = capacidadeCarga;
    }

    @Override
    public double calcularAutonomia() {
        double reducao = Math.min(capacidadeCarga * 0.01, 0.25);
        double consumoFinal = consumoBase * (1 - reducao);
        return tanque * consumoFinal;
    }
}

